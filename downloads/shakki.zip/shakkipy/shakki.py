import pygame, sys, os
from random import *
from pygame.locals import *
import subprocess, time

poyta = []
pieces = []
cords = []
cordL = ["A", "B", "C", "D", "E", "F", "G", "H"]
currentPieces = [[1, 2, 3, 5, 4, 3, 2, 1],
                 [6, 6, 6, 6, 6, 6, 6, 6],
                 [0, 0, 0, 0, 0, 0, 0, 0],
                 [0, 0, 0, 0, 0, 0, 0, 0],
                 [0, 0, 0, 0, 0, 0, 0, 0],
                 [0, 0, 0, 0, 0, 0, 0, 0],
                 [6, 6, 6, 6, 6, 6, 6, 6],
                 [1, 2, 3, 5, 4, 3, 2, 1]]
pygame.init()
pygame.mixer.init()
pygame.font.init()

boardFlipped = False

Debug_Mode = False

tick = 0

turn = "white"
screenW, screenH = 800,800

DISPLAY= pygame.display.set_mode((screenW,screenH))

castleType = ""

selectedIndex = 200
allowedToMove = True
ctr = True
checkMt = False
played = False
currentTurnNum = 1
starting = True


# Stockfish Asetukset
#{

# Stockfish Vaikeus Tasot
stockfish_dif = [600, 900, 1200, 1500, 1800, 2100, 2400, 2700, 3000]
# Valittu vaikeus taso
current_dif = 4
# Onko Stockfish Päällä tai ei
stockfishEnabled = True
# Aloittaa Stockfishin
engine = subprocess.Popen(
    './files/stockfish.exe',
    universal_newlines=True,
    stdin=subprocess.PIPE,
    stdout=subprocess.PIPE,
    )

# Oletus vaikeus taso
elo = 1350
#}

pygame.mixer.music.load('./files/vicroy.mp3')

class box:
    def __init__(self, x = 0, y = 0, w = screenW / 8, h = screenH / 8, s = 0, col = (255,0,0)):
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.s = 5 + s
        self.col = col
    def draw(self, mode = 2):
        # ---------
        if mode == 2 or mode == 1 or mode == 3:
            pygame.draw.rect(DISPLAY,self.col,(self.x,self.y, self.w, self.s))
        # |
        if mode == 2 or mode == 0 or mode == 5:
            pygame.draw.rect(DISPLAY,self.col,(self.x,self.y, self.s, self.h))
        #  |
        if mode == 2 or mode == 0 or mode == 6:
            pygame.draw.rect(DISPLAY,self.col,(self.x + (self.w - self.s),self.y, self.s, self.h))
        # _ _ _ _ _
        if mode == 2 or mode == 1 or mode == 4:
            pygame.draw.rect(DISPLAY,self.col,(self.x,(self.y + (self.h - self.s)), self.w, self.s))

class piece:
    def __init__(self, name , index, color, pos, pieceColor, selected, moveVert, p_i, h_m):
        self.index = index
        self.name = name
        self.color = color
        self.pos = pos
        self.pieceColor = pieceColor
        self.selected = selected
        self.moveVert = moveVert
        self.p_i = p_i
        self.hasMoved = h_m
    def draw(self):
        DISPLAY.blit(self.pieceColor, (int(self.pos[0] * (screenW / 8)), int(self.pos[1] * (screenH / 8))))

class nelio:
    def __init__(self, x, y, w, h, col):
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.col = col
    def draw(self,color = 0):
        if color != 0:
            pygame.draw.rect(DISPLAY,color,(self.x ,self.y,self.w,self.h))
        else:
            pygame.draw.rect(DISPLAY,self.col,(self.x ,self.y,self.w,self.h))

class textBox:
    def __init__(self, text, col, x, y, scale, weight, italic = ""):
        self.text = text
        self.col = col
        self.x = x
        self.y = y
        self.width = 0
        self.height = 0
        self.weight = weight
        self.w = int(((screenW / 8) * 0.17) * scale)
        self.font = pygame.font.SysFont('Arial', self.w, self.weight , italic)
    def draw(self):
        textsurface = self.font.render(self.text, True, self.col)
        DISPLAY.blit(textsurface,(self.x,self.y))
        self.width = textsurface.get_width()
        self.height = textsurface.get_height()

class image:
    def __init__(self, x, y, w, h, img):
        self.x = int(x)
        self.y = int(y)
        self.w = int(w)
        self.h = int(h)
        self.img = pygame.transform.scale(pygame.image.load(img), (self.w, self.h))
    def draw(self):
        DISPLAY.blit(self.img, (self.x, self.y))

# Lataa kappaleiden kuvat niiden nimen ja värin perusteella. Sitten muuta kuvien koko yhden neliön kokoiseksi (eli ikkunan leveys jaettuna kahdeksalla koska shakkilauta on 8x8)
def add(type, color):
    return pygame.transform.scale(pygame.image.load("./files/img/pieces/" + type + "_" + color + ".png"), (int((screenW / 8)),int((screenH / 8)) ))

# Lähetä komentoja stockfishille
def put(command, inf_list, tmp_time):
    pygame.event.get()
    if Debug_Mode:
        print("processing")
    engine.stdin.write(command+'\n')
    engine.stdin.flush()
    time.sleep(tmp_time)

    if command != "quit":

        engine.stdin.write('isready\n')
        engine.stdin.flush()

        while True:
            text = engine.stdout.readline().strip()

            if text == 'readyok':
                return

            elif text !='':
                inf_list.append(text)

# Etsi kappale joka on kyseisissä x ja y koordinaateissa
def toType(m_x, m_y, c_f):
    for i in c_f:
        if i.pos == (int(m_x), int(m_y)):
            return i
    return False

# Onko kukaan shakissa
def isChecked(t_p_a, crp):
    kings = [[10,10],
             [20,20]]
    kingsCol = ["red","red"]
    curK = 0

    # Etsi kuningaat laudalta ja ota niiden väri ja koordinaatit
    for i in t_p_a:
        if i.p_i == 4:
            kings[curK][0] = i.pos[0]
            kings[curK][1] = i.pos[1]
            kingsCol[curK] = i.color
            curK += 1

    # Käy jokainen vastustajan kappale läpi ja katso pystyykö se syödä kuningaan
    for j in range(2):
        for i in t_p_a:
            if i.color != kingsCol[j]:
                canM = canMove(i.pos[0], i.pos[1], kings[j][0], kings[j][1], i.name, i.moveVert, i.index, t_p_a, crp)
                if canM == True:
                    # Jos pystyy lähetä kuningaan väri takaisin
                    return kingsCol[j]

    # Jos ei mikään pysty syömään kuningasta, vastaa että kukaan ei ole shakissa
    return False

# katso onko syötetty liike shakin palojen mukainen
def canMove(p_x, p_y, m_x, m_y, type, mov_y, s_i, arr, crntpc):
    # Käy logiikka palan perusteella
    if type == "pawn":
        #
        if (arr[s_i].color == "white" and boardFlipped == False) or (arr[s_i].color == "black" and boardFlipped == True):
            # Katso jos hiiri on oikeella x akselilla
            if m_x == p_x:
                # Katso jos hiiri on oikeessa kohdass y akselilla
                if m_y >= p_y - mov_y and m_y < p_y:
                    # Jos Edessä ei ole mitään, tee liike
                    if crntpc[p_y - 1][p_x] == 0:
                        if crntpc[int(m_y)][int(m_x)] == 0:
                            return True

            # Jos hiiren x on ruudulla josta pystyy syömään
            if m_x == (p_x - 1) or m_x == (p_x + 1):
                # Ja hiiren Y on oikealla korkeudella
                if m_y == (p_y - 1):
                    # Katso onko mitään syötävää
                    if crntpc[int(m_y)][int(m_x)] != 0:
                        # Jos on syötävää ja se ei ole sama värinen kuin syöjä, syö se
                        if toType(m_x, m_y, arr) != False:
                            if toType(m_x, m_y, arr).color != arr[s_i].color:
                                return True

        if (arr[s_i].color == "white" and boardFlipped == True) or (arr[s_i].color == "black" and boardFlipped == False):
            # --||-- (Samaa logiikka, vain toisin päin)
            if m_x == p_x:
                if m_y <= p_y + mov_y and m_y > p_y:
                    if crntpc[p_y + 1][p_x] == 0:
                        if crntpc[int(m_y)][int(m_x)] == 0:
                            return True

            if m_x == (p_x - 1) or m_x == (p_x + 1):
                if m_y == (p_y + 1):
                    if crntpc[int(m_y)][int(m_x)] != 0:
                        if toType(m_x,m_y, arr) != False:
                            if toType(m_x,m_y, arr).color != arr[s_i].color:
                                return True
    if type == "rook":
        objITW = 0
        # ------
        # Katso onko hiiri oikealla rivillä
        if (m_y == p_y) and (m_x > p_x) and (m_x <= p_x + (8 - p_x)):
            # Varmista että mitään ei ole hiiren ja palasen välissä
            for i in range(int(m_x - p_x) + 1):
                if ((p_x + 1) + i) < m_x:
                    if crntpc[p_y][(p_x + 1) + i] != 0:
                        # Lisää 1 jos on jotain välissä
                        objITW += 1
        # --||--
        if (m_y == p_y) and (m_x < p_x) and (m_x >= 0):
            for i in range(p_x):
                if ((p_x - 1) - i) > m_x:
                    if crntpc[p_y][(p_x - 1) - i] != 0:
                        objITW += 1
        # --||--
        if (m_x == p_x) and (m_y > p_y) and (m_y <= p_y + (8 - p_y)):
            for i in range(int(m_y - p_y) + 1):
                if ((p_y + 1) + i) < m_y:
                    if crntpc[(p_y + 1) + i][p_x] != 0:
                        objITW += 1
        # --||--
        if (m_x == p_x) and (m_y < p_y) and (m_y >= 0):
            for i in range(p_y):
                if ((p_y - 1) - i) > m_y:
                    if crntpc[(p_y - 1) - i][p_x] != 0:
                        objITW += 1

        # Katso että hiiri on oikealla väylällä
        if m_x == p_x or m_y == p_y:
            # Mitään ei ollut välissä
            if objITW == 0:
                # Jos hiiri klikkas jonkinlaisen palan päälle
                if crntpc[int(m_y)][int(m_x)] != 0:
                    # Etsi syötävä palanen, jos se on eri värinen syö se.
                    for i in arr:
                        if i.pos == (int(m_x), int(m_y)) and i.color == arr[s_i].color:
                            return False
                return True
    if type == "bishop":
            pitw = 0
            cmm = False
            for i in range(8):
                # /
                # Jos hiiri on vinossa akselissa, katso onko siinä mitään palaa välissä
                if m_y == (p_y + 1) + i and m_x == (p_x - 1) - i:
                    # Laita cmm ("Can Make Move") True:ksi, koska hiiri on oikeassa akselissa. Tätä tarvitaan lopussa kun katsotaan onko ollut mitään välissä ja että hiiri on oikeassa akselissa
                    cmm = True
                    # Käy jokainen vino paikka läpi jonka
                    for i in range(p_x):
                        if (p_x - 1) - i > m_x:
                            # Jos tunnisti jotain välissä lisää 1 pitw:n ("Pieces in the way")
                            if crntpc[(p_y + 1) + i][ (p_x - 1) - i] != 0:
                                pitw += 1

                # \
                # --||-- Sana logikka, eri suunta vaan
                if m_y == (p_y + 1) + i and m_x == (p_x + 1) + i:
                    cmm = True
                    for i in range(8 - p_x):
                        if (p_x + 1) + i < m_x:
                            if (p_y + 1) + i < 8 and (p_x + 1) + i < 8:
                                if crntpc[(p_y + 1) + i][ (p_x + 1) + i] != 0:
                                    pitw += 1

                # /
                # --||--
                if m_y == (p_y - 1) - i and m_x == (p_x + 1) + i:
                    cmm = True
                    for i in range( 8 - p_x):
                        if (p_x + 1) + i < m_x:
                            if (p_y - 1) - i >= 0 and (p_x + 1) + i < 8:
                                if crntpc[(p_y - 1) - i][ (p_x + 1) + i] != 0:
                                    pitw += 1
                # --||--
                if m_y == (p_y - 1) - i and m_x == (p_x - 1) - i:
                    cmm = True
                    for i in range(p_x):
                        if (p_x - 1) - i > m_x:
                            if crntpc[(p_y - 1) - i][ (p_x - 1) - i] != 0:
                                pitw += 1

                # Jos mitään ei ollut välissä ja hiiri on oikealla akselilla anna tehä liike
                if pitw == 0 and cmm:
                    # Jos hiiri klikkas jonkin palan päälle, varmista että se pala on vastustajan ja syö se.
                    if crntpc[int(m_y)][int(m_x)] != 0:
                        for i in arr:
                            if i.pos == (int(m_x), int(m_y)):
                                if i.color == arr[s_i].color:
                                    return False

                                return True
                    return True
    if type == "queen":
        # Katso jos torni tai lähetti pystyy tehä liikkeen, jos pystyy tee se liike
        if canMove(p_x, p_y, m_x, m_y, "rook", 8, s_i, arr, crntpc) or canMove(p_x, p_y, m_x, m_y, "bishop", 8, s_i, arr, crntpc):
            return True
    if type == "knight":
        # Mun spagetti lautanen
        # Katso kaikki paikat läpi
        canGo = False
        if m_x == p_x - 1 and m_y == p_y - 2:
            canGo = True
        if m_x == p_x - 2 and m_y == p_y - 1:
            canGo = True
        if m_x == p_x + 1 and m_y == p_y - 2:
            canGo = True
        if m_x == p_x + 2 and m_y == p_y - 1:
            canGo = True
        if m_x == p_x - 1 and m_y == p_y + 2:
            canGo = True
        if m_x == p_x - 2 and m_y == p_y + 1:
            canGo = True
        if m_x == p_x + 1 and m_y == p_y + 2:
            canGo = True
        if m_x == p_x + 2 and m_y == p_y + 1:
            canGo = True
        # Jos hiiri on oikealla paikalla
        if canGo == True:
            # Jos paikassa on jotain Edessä ja se on vastustajan palanen, syö se
            if crntpc[int(m_y)][int(m_x)] != 0:
                for i in arr:
                    if i.pos == (int(m_x), int(m_y)):
                        if i.color == arr[s_i].color:
                            return False

                        return True
            return True

    if type == "king":
        canCastle = 0
        global castleType
        # Katsoo että onko hiiren koordinaatit yhden paikan päästä hiirestä
        if m_x >= p_x - 1 and m_x <= p_x + 1 and m_y >= p_y - 1 and m_y <= p_y + 1:
            # Katsoo että onko halutussa paikassa vihollinen, jos on, syö se.
            if crntpc[int(m_y)][int(m_x)] != 0:
                for i in arr:
                    if i.pos == (int(m_x), m_y):
                        if i.color != arr[s_i].color:
                            return True
            # Jos halutussa paikassa ei ole mitään, mene siihen
            if crntpc[int(m_y)][int(m_x)] == 0:
                return True

        # Linnoitus tsekki
        typ = toType(m_x, m_y, arr)
        if typ != False:
            itw = 0
            # Jos klikkasi tornin päälle, varmista että se ei ole liikkunut ja että se on saman värinen. (myös katsoo että hiiri on oikeassa korkeudessa)
            if typ.name == "rook" and typ.hasMoved == False and arr[s_i].hasMoved == False and typ.color == arr[s_i].color and m_y == p_y:
                if Debug_Mode:
                    print(str(typ.hasMoved) + "  " + str(arr[s_i].hasMoved))
                # Varmista että mitään ei ole kuningaan ja tornin välissä, ja että etäisyys on pitkän Linnoituksen etäisyys.
                if (m_x < p_x and boardFlipped == False) or (m_x > p_x and boardFlipped == True):
                    if abs(p_x - m_x) - 1 != 3:
                        return False
                    for i in range(abs(p_x - m_x) - 1):
                        if boardFlipped == False:
                            if crntpc[m_y][(m_x + 1) + i] != 0:
                                itw += 1
                        if boardFlipped == True:
                            if crntpc[m_y][(m_x - 1) - i] != 0:
                                itw += 1
                    # Jos ei ole, anna linnoittaa
                    if itw == 0:
                        castleType = "long"
                        return True
                # Sama, mutta lyhyt Linnoitus
                if (m_x > p_x and boardFlipped == False) or (m_x < p_x and boardFlipped == True):
                    if abs(p_x - m_x) - 1 != 2:
                        return False
                    for i in range(abs(p_x - m_x) - 1):
                        if boardFlipped == False:
                            if crntpc[m_y][(m_x - 1) - i] != 0:
                                itw += 1
                        if boardFlipped == True:
                            if crntpc[m_y][(m_x + 1) + i] != 0:
                                itw += 1
                    if itw == 0:
                        castleType = "short"
                        return True
    return False

# Katsoo onko liike laillinen
def isLegalMove(p_x, p_y, m_x, m_y, type, movm_y, s_i):
    # Tee kopio objekteistä ja palojenpaikka matrixistä
    t_p_a = []
    crp = [[0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0]]

    for i in pieces:
        t_p_a.append(piece(i.name, i.index, i.color, (i.pos[0], i.pos[1]), i.pieceColor, i.selected, i.moveVert, i.p_i, i.hasMoved))
    for i in range(8):
        for j in range(8):
            crp[i][j] = currentPieces[i][j]

    # Jos liikkeen pytstyy "Fyysisesti" tehdä
    if canMove(p_x, p_y, m_x, m_y, type, movm_y, s_i , t_p_a, crp) != False:
        # Tsekkaa onko kukaan hetkellä shakissa
        crntChk = isChecked(t_p_a, crp)
        # Tee liike kopioissa
        colR = ""
        typ = ""
        for i in t_p_a:
            if i.pos == (p_x,p_y):
                crp[p_y][p_x] = 0
                crp[m_y][m_x] = i.p_i
                eating = toType(m_x, m_y, t_p_a)
                if eating != False:
                    eating.pos = (200,200)
                i.pos = (m_x, m_y)
                colR = i.color
                typ = i.name

        # Tsekkaa onko kukaan shakissa liikkeen jälkeen
        canM = isChecked(t_p_a, crp)

        if canM != colR:
            # Jos liikkeen tekiä on hetkellä shakissa ja liikkeen jälkeen joku pelaajista on shakissa, liike ei ole laillinen
            if crntChk != False and canM != False:
                return False
            # Muuten tee liike
            return True
    # Jos ei pysty tehä liikettä sano että ei ole laillinen
    return False

# Katsoo onko kukaan shakkimatissa
def isMated():
    legalMoves = 0
    # Tsekaa onko kukaan shakissa
    checkC = isChecked(pieces, currentPieces)
    if checkC != False:
        # Joku on shakissa
        if Debug_Mode:
            print("Shakki")
        # Katsoo kaikki mahdolliset lailliset liikkeet läpi.
        for i in pieces:
            if i.color == checkC:
                for j in range(8):
                    for y in range(8):
                        if isLegalMove(i.pos[0], i.pos[1], j, y, i.name, i.moveVert, i.index) == True:
                            legalMoves += 1
        # Jos liikkeitä ei ole jäljellä, palaa truena
        if legalMoves == 0:
            if Debug_Mode:
                print("Matti")
            checkMt = True
            return True
        else:
            return False

# Linnoitus logiikka
def castle(p_x, p_y, m_x, m_y, los):
    castled = False
    canCastle2 = 0
    # Katso onko kuningas olemassa annetuissa koordinaateissa ja myös määritä se. (Ihmeellisiä erroreita tuli, niin laitoin tän varmistuksen)
    king = toType(p_x, p_y, pieces)
    if king != False:
        # Määrittelee torni palan
        rook = toType(m_x, m_y, pieces)
        # Jos haluttu Linnoitus on Lyhyt, suorita lyhyt Linnoitus logiikka
        if los == "short":
            # Varmista että Linnoituksen jälkeen pelaaja ei ole shakissa.
            for i in pieces:
                if i.color != clr.color:
                    if boardFlipped == False:
                        if isLegalMove(i.pos[0], i.pos[1], p_x + 2, p_y, i.name, i.moveVert, i.index) == True:
                            canCastle2 += 1
                    if boardFlipped == True:
                        if isLegalMove(i.pos[0], i.pos[1], p_x - 2, p_y, i.name, i.moveVert, i.index) == True:
                            canCastle2 += 1
            # Suorita Linnoitus logiikka
            if canCastle2 == 0:
                # boardFlipped on False jos Valkoinen on alhaalla
                if boardFlipped == False:
                    # Liikuta kuningas 2 paikka oikealle, paikka matrixissa
                    currentPieces[p_y][p_x] = 0
                    currentPieces[p_y][p_x + 2] = 4
                    # Liikuta torni 2 paikka vasemalle, paikka matrixissa
                    currentPieces[m_y][m_x] = 0
                    currentPieces[m_y][m_x - 2] = 1
                    # Muuta palojen objekti koordinaatit oikeaksi
                    king.pos = (p_x + 2, p_y)
                    rook.pos = (m_x - 2, m_y)
                else:
                    # -||-, mutta flipattu
                    currentPieces[p_y][p_x] = 0
                    currentPieces[p_y][p_x - 2] = 4
                    currentPieces[m_y][m_x] = 0
                    currentPieces[m_y][m_x + 2] = 1
                    king.pos = (p_x - 2, p_y)
                    rook.pos = (m_x + 2, m_y)
                # Linnoitus suoritettu
                castled = True
        # -||-
        if los == "long":
            for i in pieces:
                if i.color != clr.color:
                    if boardFlipped == False:
                        if isLegalMove(i.pos[0], i.pos[1], p_x - 2, p_y, i.name, i.moveVert, i.index) == True:
                            canCastle2 += 1
                    if boardFlipped == True:
                        if isLegalMove(i.pos[0], i.pos[1], p_x + 2, p_y, i.name, i.moveVert, i.index) == True:
                            canCastle2 += 1
            if canCastle2 == 0:
                if boardFlipped == False:
                    currentPieces[p_y][p_x] = 0
                    currentPieces[p_y][p_x - 2] = 4
                    currentPieces[m_y][m_x] = 0
                    currentPieces[m_y][m_x + 3] = 1
                    king.pos = (p_x - 2, p_y)
                    rook.pos = (m_x + 3, m_y)
                else:
                    currentPieces[p_y][p_x] = 0
                    currentPieces[p_y][p_x + 2] = 4
                    currentPieces[m_y][m_x] = 0
                    currentPieces[m_y][m_x - 3] = 1
                    king.pos = (p_x + 2, p_y)
                    rook.pos = (m_x - 3, m_y)

                castled = True
        # Jos Linnoitus onnistui
        if castled:
            # Nolla Linnoitus "tyyli"
            castleType = ""
            global turn
            global selectedIndex
            global allowedToMove
            # Vaihda vuoro
            if turn == "white":
                turn = "black"
            else:
                turn = "white"
            # Laita kuningas liikkuneeksi
            king.hasMoved = True

            if Debug_Mode:
                print(king.hasMoved)
            # Laita Torni liikkuneeksi
            rook.hasMoved = True
            # Poista Kappaleen Valinta
            selectedIndex = 200
            allowedToMove = False

            # Katso onko joku shakkimatissa
            isMated()

def dropdown(s_x, s_y, col, sf_br = ""):
    selection = []
    orj = 1
    # Muuta orientaatio sen perusteella että onko musta tai valkoinen alhaalla
    if (col == "white" and boardFlipped == False) or (col == "black" and boardFlipped == True):
        orj = 1
    else:
        orj = -1

    # Luo palat valikkoa varten
    selection.append(piece("queen", 51, col, (s_x , s_y ), add("queen", col), False, 0, 5, False))
    selection.append(piece("rook", 51, col, (s_x , s_y + (1 * orj)), add("rook", col), False, 0, 1, False))
    selection.append(piece("bishop", 51, col, (s_x , s_y + (2 * orj)), add("bishop", col), False, 0, 3, False))
    selection.append(piece("knight", 51, col, (s_x, s_y + (3 * orj)), add("knight", col), False, 0, 2, False))

    # Jos funktio on saanu stockfishiltä valikko komennon valitse sen antama pala
    if sf_br != "":
        if sf_br == "q":
            return selection[0]
        if sf_br == "r":
            return selection[1]
        if sf_br == "b":
            return selection[2]
        if sf_br == "n":
            return selection[3]
    loop = 0
    while True:
        # Piirrä pöytä
        for event in pygame.event.get():
            x, y = pygame.mouse.get_pos()[0],  pygame.mouse.get_pos()[1]

            # Piirrä shakkipöydän neliöt
            for i in poyta:
                i.draw(0)

            # Piirrä kaikki palat jotka ei ole valittavien palojen alla
            for i in pieces:
                pos = i.pos
                if pos != (s_x, s_y) and  pos != (s_x, s_y + (1 * orj)) and  pos != (s_x, s_y + (2 * orj)) and  pos != (s_x, s_y + (3 * orj)):
                    i.draw()

            # Piirrä valittavat palat
            for i in selection:
                i.draw()

            # Piirrä kurssorin luo laatikko jos se kurssori on palojen päällä.
            s_pos_x = int(s_x * (screenW / 8))
            s_box = box()
            if x >= s_pos_x and x <= s_pos_x + (screenW / 8):
                if y >= (s_y * (screenH / 8)) and  y <= ((s_y + 3) * (screenH / 8)) + (screenH / 8):
                    s_box.x = s_pos_x
                    s_box.y = int(y / (screenH / 8)) * (screenH / 8)
                    s_box.draw()

            # Valitse pala
            if event.type == pygame.MOUSEBUTTONDOWN and x >= s_pos_x and x <= s_pos_x + (screenW / 8):
                for i in selection:
                    s_pos_y = int(i.pos[1] * (screenH /8))
                    if y >= s_pos_y and y <= s_pos_y + (screenH / 8):
                        if Debug_Mode:
                            print("SI! FLUKE!")
                        return i
            if loop == 0:
                loop += 1

            pygame.display.update()

def checkMate():
    while True:
        global played
        win_w = int(screenW * 0.9)
        win_h = int(screenH * 0.3)
        win_x = int((screenW / 2) - (win_w / 2))
        win_y = int((screenH / 2) -  (win_h / 2))
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()


            for i in poyta:
                i.draw(0)

            for i in pieces:
                i.draw()

            x,y = pygame.mouse.get_pos()[0], pygame.mouse.get_pos()[1]

            # Lataa shakkimatti kuva
            pic = pygame.transform.scale(pygame.image.load("./files/img/dub.png"), (win_w , win_h))
            DISPLAY.blit(pic, (win_x, win_y))
            # Määritä napin kuva
            b_w, b_h =  int(screenW / 4), int(screenH / 11)
            b_x, b_y = (win_x + (win_w / 2)) - (b_w / 2), (win_y + win_h) + 20

            # Määritä shakkimatti kuvan koko ja laita se näytön keskelle
            pygame.draw.rect(DISPLAY,(5,140,202),(b_x, b_y, b_w, b_h))
            pic2 = pygame.transform.scale(pygame.image.load("./files/img/ng.png"), (int(b_w * 0.9), int(b_h * 0.6)))
            DISPLAY.blit(pic2, (int( (b_x + (b_w / 2)) - ((b_w * 0.9) / 2) ), int( (b_y + (b_h / 2)) - ((b_h * 0.6) / 2) )))

            # Jos pelaaja klikkaa napin päälle aloita uus peli peilatulla pöydällä
            if event.type == pygame.MOUSEBUTTONDOWN:
                if x >= b_x and x <= b_x + b_w:
                    if y >= b_y and y <= b_y + b_h:
                        resetBoard()


            pygame.display.update()

            # Soita shakkimatti ääni Kerran
            if played == False:
                pygame.mixer.music.set_volume(0.08)
                pygame.mixer.music.play(1)
                played = True

def resetBoard():
    checkMt = False
    global pieces
    global currentPieces
    global turn
    global boardFlipped
    global played
    global cords
    cords = []
    played = False
    turn = "white"
    if boardFlipped == False:
        currentPieces = [[1, 2, 3, 4, 5, 3, 2, 1],
                         [6, 6, 6, 6, 6, 6, 6, 6],
                         [0, 0, 0, 0, 0, 0, 0, 0],
                         [0, 0, 0, 0, 0, 0, 0, 0],
                         [0, 0, 0, 0, 0, 0, 0, 0],
                         [0, 0, 0, 0, 0, 0, 0, 0],
                         [6, 6, 6, 6, 6, 6, 6, 6],
                         [1, 2, 3, 4, 5, 3, 2, 1]]
        boardFlipped = True
    else:
        currentPieces = [[1, 2, 3, 5, 4, 3, 2, 1],
                         [6, 6, 6, 6, 6, 6, 6, 6],
                         [0, 0, 0, 0, 0, 0, 0, 0],
                         [0, 0, 0, 0, 0, 0, 0, 0],
                         [0, 0, 0, 0, 0, 0, 0, 0],
                         [0, 0, 0, 0, 0, 0, 0, 0],
                         [6, 6, 6, 6, 6, 6, 6, 6],
                         [1, 2, 3, 5, 4, 3, 2, 1]]
        boardFlipped = False
    # Jos stockfish on laitettu päälle lähetä sille taito vaihto, uusi peli komento ja peli paikka
    if stockfishEnabled:
        inf_list = []
        put('setoption UCI_elo 1350', inf_list, 0)
        put('ucinewgame', inf_list, 0)
        put('position fen rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', inf_list, 0)

    played = False
    currentTurn = 1
    pygame.mixer.music.load('./files/vicroy.mp3')

    pieces = []

    # Flip board
    main()

def stockfish_p(currentTurn):
    # Muuta pala matrixi stockfish pöytä-sarjaksi
    boardFen = ""
    if currentTurn == "black" or currentTurn == "b":
        currentTurn = "b"
    else:
        currentTurn = "w"
    wkc= False
    bkc= False
    for y in range(8):
        f_y = y
        if boardFlipped:
            f_y = 7 - y
        if y > 0:
            boardFen += "/"
        num = 0
        for x in range(8):
            if currentPieces[f_y][x] != 0:
                if num > 0:
                    boardFen += str(num)
                    num = 0
                pap = toType(x, f_y, pieces)
                if pap != False:
                    if currentPieces[f_y][x] == 1:
                        if pap.color == "black":
                            boardFen += "r"
                        if pap.color == "white":
                            boardFen += "R"
                    if currentPieces[f_y][x] == 2:
                        if pap.color == "black":
                            boardFen += "n"
                        if pap.color == "white":
                            boardFen += "N"
                    if currentPieces[f_y][x] == 3:
                        if pap.color == "black":
                            boardFen += "b"
                        if pap.color == "white":
                            boardFen += "B"
                    if currentPieces[f_y][x] == 4:
                        if pap.color == "black":
                            boardFen += "k"
                            bkc = pap.hasMoved
                        if pap.color == "white":
                            boardFen += "K"
                            wkc = pap.hasMoved
                    if currentPieces[f_y][x] == 5:
                        if pap.color == "black":
                            boardFen += "q"
                        if pap.color == "white":
                            boardFen += "Q"
                    if currentPieces[f_y][x] == 6:
                        if pap.color == "black":
                            boardFen += "p"
                        if pap.color == "white":
                            boardFen += "P"
            if currentPieces[f_y][x] == 0:
                num += 1
        if num > 0:
            boardFen += str(num)

#    print(boardFen)
    castleCheck = ""
    if wkc == False:
        castleCheck += "KQ"
    if bkc == False:
        castleCheck += "kq"
    inf_list = []
    # print(currentTurnNum)
    if Debug_Mode:
        print('position fen ' + boardFen + " " + currentTurn + " " + castleCheck  + ' - 0 ' + str(currentTurnNum))
    put('position fen ' + boardFen + " " + currentTurn + " " + castleCheck  + ' - 0 ' + str(currentTurnNum), inf_list, 0)

    put('go depth 12', inf_list, 0.8)
    movefound = False
    # Isolate move from list
    makeBestMove = [0,0,0,0,""]
    for i in inf_list:
        if "bestmove" in i:
            movefound = True
            word = i.split(" ")
            # Turn stockfish result into move start and end pos
            pos = word[1]
            it = 0

            temp_nArr = cordL
            if Debug_Mode:
                print(word)

            for s in temp_nArr:
                if s.lower() == pos[0]:
                    makeBestMove[0] = it
                if s.lower() == pos[2]:
                    makeBestMove[2] = it
                it += 1

            makeBestMove[1] = pos[1]

            makeBestMove[3] = pos[3]

            if len(pos) == 5:
                makeBestMove[4] = pos[4]
            return makeBestMove

    return

def move(p_x, p_y, m_x, m_y, piece, sf_br = ""):
    global castleType
    global currentTurnNum
    type = ""
    # Etsi hiiren kohdalla oleva palanen
    pieceC = toType(m_x, m_y, pieces)

    if Debug_Mode:
        print(piece)

    type = piece.name
    # Katso jos halutaan linnoittaa
    if type == "king" and pieceC != False:
        if pieceC.name == "rook" and pieceC.color == piece.color and piece.hasMoved == False and pieceC.hasMoved == False and castleType != "":
            if p_y == m_y:
                castle(p_x, p_y, m_x, m_y, castleType)
                return

    if type == "king" or type == "rook":
        piece.hasMoved = True

    for j in pieces:
        if j.pos == (m_x,m_y):
            j.pos = (200,200)

    currentPieces[p_y][p_x] = 0
    currentPieces[m_y][m_x] = piece.p_i
    piece.pos = (m_x, m_y)

    if type == "pawn":
            if ((m_y == 0 and piece.color == "white") or (m_y == 7 and piece.color == "black") and boardFlipped == False) or ((m_y == 7 and piece.color == "white") or (m_y == 0 and piece.color == "black") and boardFlipped == True):
                if sf_br != "":
                    drpdwn = dropdown(m_x, m_y, piece.color, sf_br)
                else:
                    drpdwn = dropdown(m_x, m_y, piece.color)
                if drpdwn != False:
                    piece.name = drpdwn.name
                    currentPieces[m_y][m_x] == drpdwn.p_i
                    piece.moveVert = drpdwn.moveVert
                    piece.pieceColor = add(drpdwn.name,piece.color)

    # Sotilas pystyy vaan liikkua yhden paikan ekan liikkeen jälkeen
    if piece.moveVert == 2:
        piece.moveVert = 1

    global turn
    global selectedIndex
    global allowedToMove

    # Muuta vuoro
    if turn == "white":
        turn = "black"
    else:
        currentTurnNum += 1
        turn = "white"
    # Deselectaa pala
    selectedIndex = 200
    allowedToMove = False
    return

def main():
    # Luo shakkipöydän ruutut ja koordinaatit
    for i in range(8):
        for j in range(8):
            offset = 0
            # Katso onko toinen ruutu
            if i % 2 == 0:
                offset = 1
            # Vaihda joka toisen ruutun väriä
            if (j + offset) % 2 == 0:
                col = (240,217,181)
                col2 = (181,136,99)
            else:
                col = (181,136,99)
                col2 = (240,217,181)
            # Luo ruutu
            poyta.append(nelio((screenW / 8) * i,(screenH / 8) * j, (screenW / 8), (screenH / 8), col))
            if j == 7:
                # Lisää koordinaatit pöydän orientaation mukaisesti
                if boardFlipped == False:
                    # Kirjaimet
                    cords.append(textBox(cordL[i], col2, ((screenW / 8) * i)  + ((screenW / 8) * 0.01) , ((screenH / 8) * j) + ((screenH / 8) * 0.81), 1, "bold"))
                    # Numerot
                    cords.append(textBox(str(8 - i), col2, ((screenW / 8) * j) + ((screenW / 8) * 0.87), (screenW / 8) * i, 1, "bold"))
                if boardFlipped == True:
                    #-||-
                    cords.append(textBox(cordL[7 - i], col2, ((screenW / 8) * i)  + ((screenW / 8) * 0.01) , ((screenH / 8) * j) + ((screenH / 8) * 0.81), 1, "bold"))
                    cords.append(textBox(str(i + 1), col2, ((screenW / 8) * j) + ((screenW / 8) * 0.87), (screenW / 8) * i, 1, "bold"))
    # Luo palat pala matrixin mukaisesti
    for i in range(8):
        temp_color = ""
        temp_pieceColor = ""
        for j in range(8):
            if j < 5:
                # Lait väri y koordinaatien mukaisesti
                if boardFlipped == False:
                    temp_color = "black"
                else:
                    temp_color = "white"
            else:
                if boardFlipped == False:
                    temp_color = "white"
                else:
                    temp_color = "black"
            # Katso mikä numero on pala matrixissä ja luo sen mukainen pala
            if currentPieces[j][i] == 1:
                pieces.append(piece("rook", len(pieces), temp_color, (i,j), add("rook",temp_color), False, 8, 1, False ))
            if currentPieces[j][i] == 2:
                pieces.append(piece("knight", len(pieces), temp_color, (i,j), add("knight",temp_color), False, 2, 2, False ))
            if currentPieces[j][i] == 3:
                pieces.append(piece("bishop", len(pieces), temp_color, (i,j), add("bishop",temp_color), False, 8, 3, False ))
            if currentPieces[j][i] == 4:
                pieces.append(piece("king", len(pieces), temp_color, (i,j), add("king",temp_color), False, 1, 4, False ))
            if currentPieces[j][i] == 5:
                pieces.append(piece("queen", len(pieces), temp_color, (i,j), add("queen",temp_color), False, 8, 5, False ))
            if currentPieces[j][i] == 6:
                pieces.append(piece("pawn", len(pieces), temp_color, (i,j), add("pawn",temp_color), False, 2, 6, False ))

    paused = False
    WHITE=(255,255,255)
    BLUE=(0,0,255)
    global tick
    tick = 0;
    selected = False
    selector = box()
    global selectedIndex
    si_c = 200
    global allowedToMove
    pos_draw_cache = []
    slc = 200
    firstRun = True
    while True:
        if checkMt == False:
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()
                # Stockfish liike logiikka
                if ((turn == "black" and boardFlipped == False) or (turn == "white" and boardFlipped == True)) and stockfishEnabled and firstRun == False and paused == False:
                    # Saa stockfishiltä paras liike
                    movToMake = stockfish_p(turn)

                    if Debug_Mode:
                        print(str(movToMake[0]) + " " +  str(movToMake[1]) + " " +  str(movToMake[2]) + " " +  str(movToMake[3]))

                    # Muuta liikettä laudan orientaation mukaisesti
                    if boardFlipped == False:
                        # Jos on valkoinen alhaalla älä muuta mitään
                        sf_x, sf_y, sft_x, sft_y = int(movToMake[0]), 8 - int(movToMake[1]), int(movToMake[2]),  8 - int(movToMake[3])
                    else:
                        # Jos musta on näytön ala puolella, peilaa liike
                        sf_x, sf_y, sft_x, sft_y = int(movToMake[0]), int(movToMake[1]) - 1, int(movToMake[2]), int(movToMake[3]) - 1

                    if Debug_Mode:
                        print(str(sf_x) + " " +  str(sf_y))
                    # Etsi liikutettava pala
                    pies = toType(sf_x, sf_y, pieces)

                    # Katso jos stockfish ei ole antanut pala muutos komentoa. (Eli jos soturi on päässyt vastustajan alkuun)
                    if movToMake[4] != 0:
                        # Tee normaali liike
                        move(sf_x, sf_y, sft_x , sft_y, pies, movToMake[4])
                    else:
                        # Syötä myös se palanen johon halutaan vaihtaa
                        move(sf_x, sf_y, sft_x , sft_y, pies)
                    # Katso jos joku on matissa, jos on vie peli shakkimatti näyttöön
                    if isMated():
                        checkMate()

                DISPLAY.fill(WHITE)
                x, y = pygame.mouse.get_pos()[0],  pygame.mouse.get_pos()[1]

                # Jos jokin pala on valittu luo sille koordinaatien, pala tyyppi ja max liike matka muuttuja
                if selectedIndex < len(pieces):
                    p_x, p_y, type, movm_y = pieces[selectedIndex].pos[0], pieces[selectedIndex].pos[1], pieces[selectedIndex].name, pieces[selectedIndex].moveVert

                # Piirrä pöytä ja katso jos halutaan liikutta palasta
                for i in poyta:
                    if (x > i.x and x < (i.x + i.w)) and (y > i.y and y < (i.y + i.h)) :
                        # katso jos ollaan valittu jokin pala
                        if selectedIndex < len(pieces):
                            # Hiiren koordinaatit
                            m_x, m_y = int( i.x / (screenW / 8)), int(i.y / (screenH / 8))

                            # Katso jos halutaan liikuttaa palasta ja jos se on laillinen liike
                            if event.type == pygame.MOUSEBUTTONDOWN and allowedToMove and isLegalMove(p_x, p_y, m_x, m_y, type, movm_y, selectedIndex) == True  and paused == False:
                                # Liikuta
                                move(p_x, p_y, m_x, m_y, pieces[selectedIndex])
                                # Nollaa mahdollisien liike paikkojen piirto lista
                                pos_draw_cache = []
                                # katso jos ollaan matissa
                                if isMated():
                                    checkMate()
                    # Katso jos ollaan shakissa
                    chck = isChecked(pieces, currentPieces)

                    i.draw(0)
                    # Jos ollaan shakissa, piirrä shakissa olevan kuningaan taakse punainen ruutu
                    if chck != False:
                        for p in pieces:
                            if p.name == "king" and p.color == chck:
                                if int(i.x / (screenW / 8)) == p.pos[0] and int(i.y / (screenH / 8)) == p.pos[1]:
                                    i.draw((255,0,0))

                # Valitse pala
                slc = selectedIndex
                for i in pieces:
                    i.draw()

                    # Palan koordinaatti
                    p_x = i.pos[0] * (screenW / 8)
                    p_y = i.pos[1] * (screenH / 8)
                    # Katso jos hiiri on palan päällä ja ollaan klikattu sitä
                    if event.type == pygame.MOUSEBUTTONDOWN and allowedToMove:
                        if x > p_x and x < (p_x + (screenW / 8)):
                            if y > p_y and y < (p_y + (screenH / 8)):
                                # Katso jos pala on oma
                                if turn == i.color:
                                    # Valitse se pala
                                    selectedIndex = i.index
                                    if slc == selectedIndex:
                                        selectedIndex = 200
                for i in poyta:
                    # Check where our mouse is
                    if (x > i.x and x < (i.x + i.w)) and (y > i.y and y < (i.y + i.h)):
                        # Check if we have selected a piece
                        if selectedIndex < len(pieces)  and paused == False:
                            # Move The select box to mouse2tile coordinates
                            selector.x = i.x
                            selector.y = i.y
                            selector.col = (0, 255, 0)
                            selector.draw()
                            # If the selected piece has changed, get the new legal positions for the piece
                            if si_c != selectedIndex:
                                si_c = selectedIndex
                                pos_draw_cache = []
                                # koordinaatit
                                p_x, p_y = pieces[selectedIndex].pos[0], pieces[selectedIndex].pos[1]
                                # Index, tyypi ja max matka jonka voi liikkua
                                p_i, p_t, p_m = pieces[selectedIndex].index, pieces[selectedIndex].name, pieces[selectedIndex].moveVert
                                for g_x in range(8):
                                    for g_y in range(8):
                                        if isLegalMove(p_x, p_y, g_x, g_y, p_t, p_m, selectedIndex):
                                            p_o_s_x = int((g_x * (screenW / 8)) + ((screenW / 8) / 2))
                                            p_o_s_y = int((g_y * (screenH / 8)) + ((screenH / 8) / 2))
                                            pos_draw_cache.append(((p_o_s_x, p_o_s_y)))

                # Piirrä mahdollisien paikkojen päälle merkki
                for i in range(len(pos_draw_cache)):
                    # Hae paikan koordinaatit
                    sd_x = int((pos_draw_cache[i][0] - ((screenW / 8) / 2)) / (screenW / 8))
                    sd_y = int((pos_draw_cache[i][1] - ((screenH / 8) / 2)) / (screenH / 8))

                    if paused == False:
                        if currentPieces[sd_y][sd_x] == 0:
                            # Piirrä piste jos paikassa ei ole palaa
                            pygame.draw.circle(DISPLAY, (255,0,0),(pos_draw_cache[i]), int(screenW / 40), int(screenW / 40))
                        else:
                            # Piirrä laatikko sen ympäri jos siinä on syötävä pala
                            edibleSpot = box()
                            edibleSpot.x = sd_x * (screenW / 8)
                            edibleSpot.y = sd_y * (screenW / 8)
                            edibleSpot.draw()

                # Jos ei ole mitään valittu nollaa paikka lista ja valittu pala
                if selectedIndex > len(pieces):
                    si_c = 300
                    pos_draw_cache = []

                # piirrä koordinaatit
                for i in cords:
                    i.draw()

                # Jos painaa Esc nappia peli pysähtyy
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        if paused == False:
                            paused = True
                        else:
                            paused = False

                # Jos on pausattu piirrä pause menu
                if paused:
                    # Sumenna näyttö
                    pos_draw_cache = []
                    selectedIndex = 200

                    surf2 = pygame.transform.smoothscale(DISPLAY, (int((screenW * 0.45)),int((screenH * 0.45)) ))


                    n_w, n_h = screenW, int(screenH / 8)
                    # Valkoinen tausta
                    pauseMenubg = nelio(0, 0, n_w, n_h, (255,255,255))
                    # Musta viiva eli "Stroke"
                    pmS = box(0, 0, n_w, n_h, 5, (0, 0, 0))

                    # laita sumennettu näyttö
                    DISPLAY.blit(pygame.transform.smoothscale(surf2, (int(screenW * 0.999), int(screenH * 0.999))), (0,0))

                    conText = textBox("Jatka", (0,0,0), screenW / 4, screenH * 0.005 , 4, "")
                    menText = textBox("Alkuun", (0,0,0), screenW / 4, screenH * 0.005 , 4, "")
                    conText.x = (screenW / 4) - conText.w
                    menText.x = (screenW * 0.75) - conText.w
                    pauseMenubg.draw()
                    pmS.draw(4)
                    conText.draw()
                    menText.draw()
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        # Katso jos hiiri on ensimmäisen napin alueella
                        if y <= n_h:
                            if x < screenW / 2:
                                paused = False
                            if x > screenW / 2:
                                mainMenu()


                allowedToMove = True
                pygame.display.update()
                if firstRun:
                    firstRun = False

# Valmistele muuttujat peliä varten
def startGame():

    global engine
    global stockfishEnabled
    global pieces
    global currentPieces
    global boardFlipped
    global turn
    global elo
    turn = "white"
    boardFlipped = False
    # Jos uus peli on stockfishillä, aloita se
    if stockfishEnabled:
        inf_list = []
        if Debug_Mode:
            print(elo)
        put('setoption UCI_elo ' + str(elo), inf_list, 0)
        put('ucinewgame', inf_list, 0)
    # Poista kappaleet ja laita palojen paikka matrix alku asentoon
    pieces = []
    currentPieces = [[1, 2, 3, 5, 4, 3, 2, 1],
                     [6, 6, 6, 6, 6, 6, 6, 6],
                     [0, 0, 0, 0, 0, 0, 0, 0],
                     [0, 0, 0, 0, 0, 0, 0, 0],
                     [0, 0, 0, 0, 0, 0, 0, 0],
                     [0, 0, 0, 0, 0, 0, 0, 0],
                     [6, 6, 6, 6, 6, 6, 6, 6],
                     [1, 2, 3, 5, 4, 3, 2, 1]]
    # Mene peliin
    main()

def mainMenu():
    global stockfishEnabled
    global elo
    global stockfish_dif
    global current_dif
    w_y = 0
    # Asetuksien ikkunan koko ja koordinaatit
    s_w, s_h = 240, 50
    s_x, s_y = (screenW - s_w) - 50, 50
    settingsEnabled = False

    while True:
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()

            # Luo mainmenun taustakuva
            bg = image(0,0, screenW, screenH, "./files/img/background.png")

            # Laske nappien koko ikkunan koon perusteella
            sfb_w, sfb_h = int(screenW / 4), int(screenH / 12)

            # Laske nappien paikat
            sfb_x, sfb_y = int((screenW / 2) - (sfb_w / 2)), int((screenH / 2) - (sfb_h / 2))
            nb_x, nb_y = int((screenW / 2) - (sfb_w / 2)), int((screenH * 0.65) - (sfb_h / 2))


            x, y = pygame.mouse.get_pos()[0],  pygame.mouse.get_pos()[1]

            # Luo napit
            sfb = nelio(sfb_x, sfb_y, sfb_w, sfb_h, (255,255,255))
            nb = nelio(nb_x, nb_y, sfb_w, sfb_h, (255,255,255))

            # Luo nappien päällä olevat mustat raidat
            b_b = box(sfb.x, sfb.y, sfb.w, sfb.h, 2)
            b_b1 = box(nb.x, nb.y, sfb.w, sfb.h, 2)

            # Ensimmäisen napin kuva
            np1 = image(sfb.x, sfb.y, sfb.w, sfb.h, "./files/img/1nup.png")

            # Toisen napin kuva
            np2 = image(nb.x, nb.y, sfb.w, sfb.h, "./files/img/2nup.png")

            # Katso onko hiiri ensimmäisen napin kohdalla
            if x > sfb_x and x < sfb_x + sfb_w:
                if y > sfb_y and y < sfb_y + sfb_h:
                    w_y = sfb_y + ((sfb_h / 2) - (((screenH / 8) * 0.74) / 2)) - 2
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        stockfishEnabled = False
                        startGame()

            # Katso onko hiiri toisen napin kohdalla
            if x > nb_x and x < nb_x + sfb_w:
                if y > nb_y and y < nb_y + sfb_h:
                    # Laita torni kuvien y napin kohdalle
                    w_y = nb_y + ((sfb_h / 2) - (((screenH / 8) * 0.74) / 2)) - 2

                    if event.type == pygame.MOUSEBUTTONDOWN:
                        stockfishEnabled = True
                        # Päivitä Elo
                        elo = stockfish_dif[current_dif]
                        startGame()


            # Jos tornien kuva paikkaa ei olla määritetty vielä (Eli kun hiiri ei ole ollut yhenkään napin päällä) laita se ensimmäisen painikkeen päälle
            if w_y == 0:
                w_y = sfb_y + ((sfb_h / 2) - (((screenH / 8) * 0.74) / 2)) - 2

            # Laske torni kuvan leveys ja korkeus
            r_w, r_h = (screenW / 8) * 0.75, (screenH / 8) * 0.75

            # Luo tornikuvat
            rook = image(((screenW / 2) - (r_w / 2)) - (sfb_w / 1.5), w_y, r_w, r_h, "./files/img/pieces/rook_white.png")
            rook1 = image(((screenW / 2) - (r_w / 2)) + (sfb_w / 1.5), w_y, r_w, r_h, "./files/img/pieces/rook_white.png")

            # Tee napin päällä olevat raidat mustaksi
            b_b.col = (0,0,0)
            b_b1.col = (0,0,0)
            if event.type == pygame.MOUSEBUTTONDOWN:
                if x >= screenW * 0.92:
                    if y < screenH * 0.07:
                        if settingsEnabled == True:
                            settingsEnabled = False
                        else:
                            settingsEnabled = True

            # Piirrä napit, kuvat ja tekstit
            bg.draw()
            sfb.draw()
            nb.draw()
            np1.draw()
            np2.draw()
            b_b.draw(1)
            b_b1.draw(1)
            rook.draw()
            rook1.draw()

            if settingsEnabled:
                # Asetus ikkunan tausta
                settings_bg = nelio(s_x, s_y, s_w, s_h, (255,255,255))
                # Asetus ikkunan napit
                slct1 = nelio(s_x + 130, s_y + 18, 15, 15, (0,0,0))
                slct2 = nelio(s_x + 150, s_y + 18, 15, 15, (0,0,0))
                # Tunnista jos kilkataan asetus ikkunan nappien päälle
                if event.type == pygame.MOUSEBUTTONDOWN:
                    # Varmista että hiiri on oikealla korkeudella
                    if y >= s_y + 18 and y <= s_y + 33:
                        # Varmista että hiiren x on napin päällä
                        if x >= s_x + 130 and x <= s_x + 145:
                            current_dif -= 1
                        if x >= s_x + 150 and x <= s_x + 165:
                            current_dif += 1
                        # Muuta valittua eloa nappien perusteella
                        current_dif = current_dif % (len(stockfish_dif ))
                # Luo nappien luonna olevat tekstit
                elo_text = textBox(str(stockfish_dif[current_dif]), (0,0,0), s_x + 180, s_y + 12, 1.3, ""  )
                set_text = textBox("Stockfish Elo: ", (0,0,0), s_x + 10, s_y + 11, 1.3, ""  )
                # Luo asetuksien kehys
                settings_border = box(s_x, s_y, s_w, s_h, 1)
                settings_bg.draw()
                slct1.draw()
                slct2.draw()
                settings_border.draw()
                elo_text.draw()
                set_text.draw()


            pygame.display.update()

mainMenu()
